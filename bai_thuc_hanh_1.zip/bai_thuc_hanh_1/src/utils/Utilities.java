package utils;

public class Utilities {
	public static int findElementInArray(String[] array, String value) {
		if (array == null) {
			return -1;
		}
		for (int i = 0; i < array.length; i++) {
			if (array[i].equals(value)) {
				return i;
			}
		}
		return -1;
	}
	
	public static String arrayToString(String[] array) {
		String result = "";
		for(String item : array) {
			result += item + ", ";
		}
		return result.equals("") ? result : result.substring(0, result.length() - 2);
	}
}
