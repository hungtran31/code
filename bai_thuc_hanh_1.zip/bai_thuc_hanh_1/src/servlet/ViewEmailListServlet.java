package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import business.User;
import data.UserIO;

/**
 * Servlet implementation class ViewEmailListServlet
 */
@WebServlet("/ViewEmailList")
public class ViewEmailListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewEmailListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String query = request.getParameter("query");
		ServletContext sc = getServletContext();
		String path = sc.getRealPath("/WEB-INF/emailList.dat");
		ArrayList<User> users;
		
		if(query != null && !query.equals("")) {
			users = UserIO.getByEmail(path, query);
		} else {
			users = UserIO.getAll(path);
		}
		request.setAttribute("users", users);
		request.setAttribute("query", query);
		request.getRequestDispatcher("view_email_list.jsp").forward(request, response);;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
