package business;

import java.io.Serializable;

public class User implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3216140069369807315L;
	private String firstName;
	private String lastName;
	private String email;
	private String[] musicInterests;

	public User() {
		this.firstName = "";
		this.lastName = "";
		this.email = "";
		this.musicInterests = null;
	}

	public User(String firstName, String lastName, String email) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.musicInterests = null;
	}

	public User(String firstName, String lastName, String email, String[] musicInterests) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.musicInterests = musicInterests;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String[] getMusicInterests() {
		return musicInterests;
	}

	public void setMusicInterests(String[] musicInterests) {
		this.musicInterests = musicInterests;
	}

	@Override
	public String toString() {
		String result = firstName + "~" + lastName + "~" + email;
		for (String item : musicInterests) {
			result += "~" + item;
		}
		return result;
	}
}
