package data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import business.User;

public class UserIO {
	public static void writeUser(String path, User user) {
		try {
			File file = new File(path);
			if (!file.exists()) {
				file.createNewFile();
			}
			ArrayList<User> users = new ArrayList<>();
			try (FileInputStream fis = new FileInputStream(file); ObjectInputStream ois = new ObjectInputStream(fis)) {
				Object usersObject = ois.readObject();
				if (usersObject != null) {
					users = (ArrayList<User>) usersObject;
				}
				users.add(user);
				try (FileOutputStream fos = new FileOutputStream(file);
						ObjectOutputStream oos = new ObjectOutputStream(fos)) {
					oos.writeObject(users);
				}
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static ArrayList<User> getAll(String path) {
		try {
			File file = new File(path);
			if (!file.exists()) {
				file.createNewFile();
			}
			ArrayList<User> users = new ArrayList<>();
			try (FileInputStream fis = new FileInputStream(file); ObjectInputStream ois = new ObjectInputStream(fis)) {
				users = (ArrayList<User>) ois.readObject();
			}
			return users;

		} catch (Exception e) {
			System.out.println(e.getMessage());
			return new ArrayList<>();
		}
	}
	
	public static ArrayList<User> getByEmail(String path, String email) {
		try {
			File file = new File(path);
			if (!file.exists()) {
				file.createNewFile();
			}
			ArrayList<User> users = new ArrayList<>();
			try (FileInputStream fis = new FileInputStream(file); ObjectInputStream ois = new ObjectInputStream(fis)) {
				users = (ArrayList<User>) ois.readObject();
			}
			ArrayList<User> result = new ArrayList<>();
			for(User user: users) {
				if(user.getEmail().toLowerCase().contains(email.toLowerCase())) {
					result.add(user);
				}
			}
			return result;

		} catch (Exception e) {
			System.out.println(e.getMessage());
			return new ArrayList<>();
		}
	}
}
