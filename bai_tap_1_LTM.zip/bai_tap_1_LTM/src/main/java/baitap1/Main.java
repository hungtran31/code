package baitap1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Main {

    private static final String FILE_STUDENT = "STUDENT.TXT";
    static Scanner in = new Scanner(System.in);
    static List<Student> list = new ArrayList<>();

    private static void input(int sl, List list) {
        for (int i = 0; i < sl; i++) {
            System.out.println("nhap msv: ");
            String msv = in.nextLine();
            System.out.println("Nhap ho va ten: ");
            String name = in.nextLine();
            System.out.println("Nhom: ");
            int gr = Integer.parseInt(in.nextLine());
            Student s = new Student(msv, name, gr);
            list.add(s);
        }
    }

    private static List<Student> getListStudents() {
        List<Student> students = new ArrayList<>();
        FileIO.readFromFile(students, FILE_STUDENT);
        return students;
    }

    private static void saveStudentToFile(List list, String file) {
        FileIO.writeToFile(list, file);
    }

    private static void update() {
        List<Student> ls = getListStudents();
        System.out.println("Nhap ma sv cap nhat: ");
        String msv = in.nextLine();
        int i;
        for(i=0; i<ls.size(); i++){
            if (ls.get(i).getMaSV().equals(msv)) {
                System.out.println("nhap msv: ");
                String maSinhVien = in.nextLine();
                System.out.println("Nhap ho va ten: ");
                String tenSV = in.nextLine();
                System.out.println("Nhom: ");
                int gr = Integer.parseInt(in.nextLine());
                Student s = new Student(maSinhVien, tenSV, gr);
                ls.set(i, s);
                saveStudentToFile(ls, FILE_STUDENT);
                display(ls);
                break;
            }
        }
    }
    
    private static void display(List ls) {
        ls = getListStudents();
        ls.forEach(item -> {
            System.out.println(item.toString());
        });
    }

    public static void main(String[] args) {
        //nhap danh sach sinh vien:
        System.out.println("Nhap so luong sinh vien: ");
        int n = Integer.parseInt(in.nextLine());
        input(n, list);

        //luu danh sach sinh vien vua nhap vao file.
        saveStudentToFile(list, FILE_STUDENT);

        //hien thi danh sach sinh vien.
        display(list);
        
        //cap nhat thong tin sinh vien.
        update();
    }
}
