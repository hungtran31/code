package baitap1;

import java.io.Serializable;


public class Student implements Serializable{
    private String maSV;
    private String name;
    private int gr;

    public Student() {
    }

    public Student(String maSV, String name, int gr) {
        this.maSV = maSV;
        this.name = name;
        this.gr = gr;
    }

    public String getMaSV() {
        return maSV;
    }

    public void setMaSV(String maSV) {
        this.maSV = maSV;
    }

    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public int getgr() {
        return gr;
    }

    public void setgr(int gr) {
        this.gr = gr;
    }

    @Override
    public String toString() {
        return "Thong tin sv: " + this.maSV + " || " + this.name + " || " + this.gr;
    }
}
