
package music;

import business.User;
import data.UserIO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DisplayMusicChoices extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
        // get parameters from the request
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String emailAddress = request.getParameter("emailAddress");
        String[] music = request.getParameterValues("music");
        
        String listMusic = "<ul>";
        for(int i = 0; i < music.length; i++){
            listMusic += "<li>" + music[i];
        }
 
        // send response to browser
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println(
            "<!doctype html public \"-//W3C//DTD HTML 4.0 "
            + " Transitional//EN\">\n"
            + "<html>\n"
            + "<head>\n"
            + " <title>Murach's Java Servlets and JSP</title>\n"
            + "</head>\n"
            + "<body>\n"
            + "<h1>Thanks for joining our email list " + firstName+ " " +lastName + "</h1>\n"
            + "<p>We will use this email to notify you wherever we have new releases for these types of music: </p>\n"
            + listMusic
            + "</body>\n"
            + "</html>\n");

        out.close();
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        doPost(request, response);
    }
}